<?php
/**
 * Schema.org JSON-LD for Pascal Roth pages (complements Yoast WebPage/Breadcrumb output).
 *
 * @package Leadwerk_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Canonical business entity ID for cross-references.
 *
 * @return string
 */
function leadwerk_theme_pascal_business_schema_id() {
	return trailingslashit( home_url( '/' ) ) . '#localbusiness';
}

/**
 * Canonical organization entity ID.
 *
 * @return string
 */
function leadwerk_theme_pascal_organization_schema_id() {
	return trailingslashit( home_url( '/' ) ) . '#organization';
}

/**
 * Shared LocalBusiness / FinancialService node.
 *
 * @return array<string,mixed>
 */
function leadwerk_theme_pascal_get_business_schema_node() {
	$image = function_exists( 'leadwerk_theme_get_default_social_image_url' )
		? leadwerk_theme_get_default_social_image_url()
		: '';

	return array(
		'@type'       => array( 'FinancialService', 'LocalBusiness' ),
		'@id'         => leadwerk_theme_pascal_business_schema_id(),
		'name'        => 'Pascal Roth · Finanzberatung Karlsruhe',
		'url'         => home_url( '/' ),
		'description' => 'Finanzberatung und Finanzplanung in Karlsruhe, orientiert an Lebensphasen, persönlich und ohne Verkaufsdruck.',
		'telephone'   => '+4972493260',
		'email'       => 'pascal.roth@allfinanz.ag',
		'priceRange'  => 'Erstberatung kostenlos',
		'areaServed'  => array(
			'@type' => 'City',
			'name'  => 'Karlsruhe',
		),
		'address'     => array(
			'@type'           => 'PostalAddress',
			'addressLocality' => 'Karlsruhe',
			'addressRegion'   => 'Baden-Württemberg',
			'addressCountry'  => 'DE',
		),
		'image'       => $image,
		'parentOrganization' => array(
			'@id' => leadwerk_theme_pascal_organization_schema_id(),
		),
	);
}

/**
 * Shared Organization node (logo + brand).
 *
 * @return array<string,mixed>
 */
function leadwerk_theme_pascal_get_organization_schema_node() {
	$logo = leadwerk_theme_static_asset_url( 'Fotos/Pascal Roth Logo_blau.webp' );

	return array(
		'@type' => 'Organization',
		'@id'   => leadwerk_theme_pascal_organization_schema_id(),
		'name'  => 'Pascal Roth Finanzberatung',
		'url'   => home_url( '/' ),
		'logo'  => array(
			'@type'  => 'ImageObject',
			'url'    => $logo,
			'width'  => 200,
			'height' => 48,
		),
		'image' => $logo,
	);
}

/**
 * Extract JSON-LD blocks from a Pascal shell HTML head.
 *
 * @param string $source_key Source key.
 * @return array<int,array<string,mixed>>
 */
function leadwerk_theme_pascal_extract_shell_json_ld_blocks( $source_key ) {
	if ( ! function_exists( 'leadwerk_theme_pascal_get_shell_html' ) ) {
		return array();
	}

	$html = leadwerk_theme_pascal_get_shell_html( $source_key );
	if ( '' === $html || ! preg_match( '#<head\b[^>]*>(.*?)</head>#is', $html, $head_match ) ) {
		return array();
	}

	$blocks = array();
	if ( ! preg_match_all( '#<script\b[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>#is', $head_match[1], $matches ) ) {
		return array();
	}

	foreach ( $matches[1] as $json_text ) {
		$data = json_decode( trim( (string) $json_text ), true );
		if ( is_array( $data ) && ! empty( $data ) ) {
			$blocks[] = $data;
		}
	}

	return $blocks;
}

/**
 * Resolve relative schema string values to absolute URLs.
 *
 * @param mixed  $value       Value.
 * @param string $source_file Shell file path.
 * @return mixed
 */
function leadwerk_theme_pascal_normalize_schema_value( $value, $source_file = '' ) {
	if ( is_array( $value ) ) {
		$normalized = array();
		foreach ( $value as $key => $item ) {
			$normalized[ $key ] = leadwerk_theme_pascal_normalize_schema_value( $item, $source_file );
		}
		return $normalized;
	}

	if ( ! is_string( $value ) || '' === trim( $value ) ) {
		return $value;
	}

	if ( preg_match( '#^https?://#i', $value ) ) {
		return str_replace(
			array( 'https://pascal-roth.de', 'http://pascal-roth.de' ),
			home_url(),
			$value
		);
	}

	if ( preg_match( '#^(?:\.\./)*Fotos/#i', $value ) || 0 === stripos( $value, 'Fotos/' ) ) {
		$relative = function_exists( 'leadwerk_theme_pascal_resolve_relative_path' )
			? leadwerk_theme_pascal_resolve_relative_path( $value, $source_file )
			: ltrim( preg_replace( '#^\.\./#', '', str_replace( '\\', '/', $value ) ), '/' );

		if ( '' !== $relative ) {
			return leadwerk_theme_static_asset_url( $relative );
		}
	}

	return $value;
}

/**
 * Normalize one schema node for the current WordPress site.
 *
 * @param array<string,mixed> $node        Schema node.
 * @param int                 $post_id     Post ID.
 * @param string              $source_file Source shell file.
 * @return array<string,mixed>
 */
function leadwerk_theme_pascal_normalize_schema_node( array $node, $post_id, $source_file = '' ) {
	$node = leadwerk_theme_pascal_normalize_schema_value( $node, $source_file );

	if ( isset( $node['url'] ) && is_string( $node['url'] ) && false !== strpos( $node['url'], 'pascal-roth.de' ) ) {
		$node['url'] = get_permalink( $post_id );
	}

	if ( isset( $node['@type'] ) && 'Person' === $node['@type'] ) {
		$node['url'] = get_permalink( $post_id );
	}

	return $node;
}

/**
 * Build FAQPage schema from visible FAQ accordion markup.
 *
 * @param string $html Rendered page HTML.
 * @return array<string,mixed>|null
 */
function leadwerk_theme_pascal_build_faq_schema_from_html( $html ) {
	$html = trim( (string) $html );
	if ( '' === $html || false === stripos( $html, 'faq-item' ) ) {
		return null;
	}

	$doc = new DOMDocument();
	libxml_use_internal_errors( true );
	$loaded = $doc->loadHTML( '<?xml encoding="utf-8" ?>' . $html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
	libxml_clear_errors();
	if ( ! $loaded ) {
		return null;
	}

	$xpath    = new DOMXPath( $doc );
	$entities = array();

	foreach ( $xpath->query( '//*[contains(@class,"faq-item")]' ) as $item ) {
		if ( ! $item instanceof DOMElement ) {
			continue;
		}

		$question_node = null;
		foreach ( array(
			'.//*[contains(@class,"faq-trigger__label")]',
			'.//button[contains(@class,"faq-trigger")]',
		) as $query ) {
			$found = $xpath->query( $query, $item );
			if ( $found instanceof DOMNodeList && $found->length > 0 && $found->item( 0 ) instanceof DOMElement ) {
				$question_node = $found->item( 0 );
				break;
			}
		}

		$answer_node = null;
		foreach ( array(
			'.//*[contains(@class,"faq-answer")]',
			'.//*[contains(@class,"faq-content")]//p[1]',
		) as $query ) {
			$found = $xpath->query( $query, $item );
			if ( $found instanceof DOMNodeList && $found->length > 0 && $found->item( 0 ) instanceof DOMElement ) {
				$answer_node = $found->item( 0 );
				break;
			}
		}

		$question = $question_node instanceof DOMElement ? trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $question_node->textContent ) ) ) : '';
		$answer   = $answer_node instanceof DOMElement ? trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $answer_node->textContent ) ) ) : '';

		if ( '' === $question || '' === $answer ) {
			continue;
		}

		$entities[] = array(
			'@type'          => 'Question',
			'name'           => $question,
			'acceptedAnswer' => array(
				'@type' => 'Answer',
				'text'  => $answer,
			),
		);
	}

	if ( empty( $entities ) ) {
		return null;
	}

	return array(
		'@type'      => 'FAQPage',
		'mainEntity' => $entities,
	);
}

/**
 * Replace nested FinancialService provider objects with canonical @id references.
 *
 * @param mixed  $node        Schema node.
 * @param string $business_id Business @id.
 * @return mixed
 */
function leadwerk_theme_pascal_reference_business_entity( $node, $business_id ) {
	if ( is_array( $node ) ) {
		if ( isset( $node['@type'] ) ) {
			$types = array_map( 'strval', (array) $node['@type'] );
			if ( array_intersect( $types, array( 'FinancialService', 'LocalBusiness' ), true ) && isset( $node['telephone'] ) ) {
				return array( '@id' => $business_id );
			}
		}

		$referenced = array();
		foreach ( $node as $key => $value ) {
			$referenced[ $key ] = leadwerk_theme_pascal_reference_business_entity( $value, $business_id );
		}
		return $referenced;
	}

	return $node;
}

/**
 * Fallback Service schema for pages without shell JSON-LD.
 *
 * @param string $source_key Source key.
 * @param int    $post_id    Post ID.
 * @return array<string,mixed>|null
 */
function leadwerk_theme_pascal_get_fallback_service_schema( $source_key, $post_id ) {
	$services = array(
		'pascal-spaetstarter-v1' => array(
			'serviceType' => 'Finanzberatung Spätstarter 50+',
			'name'        => 'Spätstarter 50+ – Pascal Roth',
			'description' => 'Finanzberatung Karlsruhe ab 50+: Altersvorsorge und Finanzplanung ehrlich einordnen – mit Pascal Roth, verständlich und ohne Druck.',
			'audience'    => 'Menschen ab 50, Spätstarter:innen',
		),
		'pascal-veraenderung-v1' => array(
			'serviceType' => 'Finanzberatung bei Lebensveränderung',
			'name'        => 'Lebensveränderung – Pascal Roth',
			'description' => 'Finanzberatung Karlsruhe bei Lebensveränderung: Finanzen nach Trennung, Jobwechsel oder Umzug neu sortieren – ruhig und strukturiert.',
			'audience'    => 'Menschen in Lebensveränderung',
		),
	);

	if ( ! isset( $services[ $source_key ] ) ) {
		return null;
	}

	$service = $services[ $source_key ];

	return array(
		'@type'       => 'Service',
		'serviceType' => $service['serviceType'],
		'name'        => $service['name'],
		'description' => $service['description'],
		'url'         => get_permalink( $post_id ),
		'provider'    => array(
			'@id' => leadwerk_theme_pascal_business_schema_id(),
		),
		'areaServed'  => 'Karlsruhe',
		'audience'    => array(
			'@type'        => 'Audience',
			'audienceType' => $service['audience'],
		),
	);
}

/**
 * Whether structured data should be skipped for one source key.
 *
 * @param string $source_key Source key.
 * @return bool
 */
function leadwerk_theme_pascal_skip_structured_data( $source_key ) {
	return in_array(
		(string) $source_key,
		array(
			'pascal-impressum-v1',
			'pascal-datenschutz-v1',
			'pascal-legal-v1',
			'pascal-404-v1',
			'pascal-danke-v1',
		),
		true
	);
}

/**
 * Build the final @graph for one Pascal page.
 *
 * @param int $post_id Post ID.
 * @return array<int,array<string,mixed>>
 */
function leadwerk_theme_pascal_build_structured_data_graph( $post_id ) {
	$post_id    = (int) $post_id;
	$source_key = sanitize_key( (string) get_post_meta( $post_id, 'leadwerk_source_key', true ) );

	if ( $post_id <= 0 || ! function_exists( 'leadwerk_theme_is_pascal_source_key' ) || ! leadwerk_theme_is_pascal_source_key( $source_key ) ) {
		return array();
	}

	if ( leadwerk_theme_pascal_skip_structured_data( $source_key ) ) {
		return array();
	}

	$source_file = (string) get_post_meta( $post_id, 'leadwerk_source_file', true );
	$graph       = array(
		leadwerk_theme_pascal_get_organization_schema_node(),
		leadwerk_theme_pascal_get_business_schema_node(),
	);

	foreach ( leadwerk_theme_pascal_extract_shell_json_ld_blocks( $source_key ) as $block ) {
		if ( isset( $block['@type'] ) && 'FAQPage' === $block['@type'] ) {
			continue;
		}

		$block_types = array_map( 'strval', (array) ( $block['@type'] ?? array() ) );
		if ( array_intersect( $block_types, array( 'FinancialService', 'LocalBusiness' ), true ) ) {
			continue;
		}

		$block = leadwerk_theme_pascal_normalize_schema_node( $block, $post_id, $source_file );
		$block = leadwerk_theme_pascal_reference_business_entity( $block, leadwerk_theme_pascal_business_schema_id() );
		$graph[] = $block;
	}

	$fallback_service = leadwerk_theme_pascal_get_fallback_service_schema( $source_key, $post_id );
	if ( null !== $fallback_service ) {
		$graph[] = $fallback_service;
	}

	if ( function_exists( 'leadwerk_theme_render_current_page_content' ) ) {
		$faq_schema = leadwerk_theme_pascal_build_faq_schema_from_html(
			leadwerk_theme_render_current_page_content( $post_id )
		);
		if ( is_array( $faq_schema ) ) {
			$graph[] = $faq_schema;
		}
	}

	return $graph;
}

/**
 * Output Pascal JSON-LD in wp_head.
 *
 * @return void
 */
function leadwerk_theme_output_pascal_structured_data() {
	if ( is_admin() || ! is_singular( 'page' ) ) {
		return;
	}

	$post_id = (int) get_queried_object_id();
	$graph   = leadwerk_theme_pascal_build_structured_data_graph( $post_id );
	if ( empty( $graph ) ) {
		return;
	}

	$payload = wp_json_encode(
		array(
			'@context' => 'https://schema.org',
			'@graph'   => array_values( $graph ),
		),
		JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
	);

	if ( ! is_string( $payload ) || '' === $payload ) {
		return;
	}

	echo '<script type="application/ld+json" class="leadwerk-pascal-schema">' . $payload . "</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}
add_action( 'wp_head', 'leadwerk_theme_output_pascal_structured_data', 20 );
